KANHA ATELIER - UPDATE (gallery + catalog merge + Vercel build fix)

GitHub par upload kaise karein:
1. GitHub repo kholo -> "Add file" -> "Upload files"
2. Is zip ko kholo. Andar jo "frontend" folder hai, use poora drag-drop karo.
3. Neeche "Commit changes" dabao (main branch par).
4. Vercel apne aap naya deploy chalayega.

Agar ".npmrc" file upload na ho (hidden file hoti hai), koi baat nahi - vercel.json mein wahi setting hai.
